package com.example.TeamPortfolio.repsitory;

import com.example.TeamPortfolio.domain.Movie;
import com.example.TeamPortfolio.repository.MovieRepository;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.stream.IntStream;

@SpringBootTest
@Log4j2
public class MovieRepositoryTest {
    @Autowired
    private MovieRepository movieRepository;

    @Test
    public void testInsert(){
        IntStream.range(1,10).forEach(i -> {
            Movie movie = Movie.builder()
                    .movieName("우리팀 화이팅"+i)
                    .movieDate("월월"+ i +"일")

                    .movieAge("안녕")
                    .movieCost(100000L)
                    .movieAge("막아무나")

                    .movieAge("막아무나봐")

                    .movieCost(165165156L)
                    .build();
            Movie result = movieRepository.save(movie);
            //log.info("번호: " + result.getMovieName());
        });
    }
}
