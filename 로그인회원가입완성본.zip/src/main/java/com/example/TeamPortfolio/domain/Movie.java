package com.example.TeamPortfolio.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Movie {

    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(length = 30, nullable = false)
    private String movieName;

    @Column(length = 20, nullable = false)
    private String movieDate;

    @Column(length = 5, nullable = false)
    private String movieAge;

    @Column(length = 11, nullable = false)
    private Long movieCost;
}
