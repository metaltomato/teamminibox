package com.example.TeamPortfolio.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reservationNO;

    @Column(length = 20, nullable = false)
    private String area;

    @Column(length = 20, nullable = false)
    private String zone;

    @Column(nullable = false)
    private int buy;

    @Column(length = 5, nullable = false)
    private String location;

    @Column(nullable = false)
    private int cost;
}
