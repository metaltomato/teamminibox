package com.example.TeamPortfolio.domain;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@MappedSuperclass
@EntityListeners(value = {AuditingEntityListener.class})
@Getter
abstract class DateEntity {
    @CreatedDate
    @Column(name = "viewDay", updatable = false)
    private LocalDateTime viewDay;

    @CreatedDate
    @Column(name = "payDay", updatable = false)
    private LocalDateTime payDay;
}
