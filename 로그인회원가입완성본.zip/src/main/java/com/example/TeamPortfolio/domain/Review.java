package com.example.TeamPortfolio.domain;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Data
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reviewId;

    @Column
    private String reviewTitle;

    @Column
    private String reviewText;

    @Column
    private LocalDate reviewDate;
}
