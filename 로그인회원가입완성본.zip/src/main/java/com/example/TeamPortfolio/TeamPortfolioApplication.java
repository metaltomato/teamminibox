package com.example.TeamPortfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamPortfolioApplication.class, args);
	}

}
