package com.example.TeamPortfolio.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.core.user.OAuth2User;

import lombok.Data;

@Data
public class CustomerJoinDTO {
    private String cid;
    private String cpw;
    private String email;
    private boolean del;
    private boolean social;
}

