package com.example.TeamPortfolio.service;

import com.example.TeamPortfolio.domain.Movie;
import com.example.TeamPortfolio.dto.MovieDTO;
import com.example.TeamPortfolio.repository.MovieRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class MovieService {
    private final MovieRepository movieRepository;
    Movie dtoToEntity(MovieDTO movieDTO){
        Movie movie = Movie.builder()
                .movieName(movieDTO.getMovieName())
                .movieDate(movieDTO.getMovieDate())
                .movieAge(movieDTO.getMovieAge())
                .movieCost(movieDTO.getMovieCost())
                .build();
                return movie;
    }

     public String register(MovieDTO movieDTO){
     Movie movie = dtoToEntity(movieDTO);
     String movieName = movieRepository.save(movie).getMovieName();
     return movieName;
    }

    void remove(String movieName){
        movieRepository.deleteById(movieName);
    }
}
