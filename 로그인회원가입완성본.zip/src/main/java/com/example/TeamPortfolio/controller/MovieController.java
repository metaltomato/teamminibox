package com.example.TeamPortfolio.controller;

import com.example.TeamPortfolio.dto.MovieDTO;
import com.example.TeamPortfolio.service.MovieService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/movie")
@RequiredArgsConstructor
@Log4j2
public class MovieController {

    private final MovieService movieService;

    @GetMapping("/register")
    public void registerGET(){

    }

    @PostMapping("/register")
    public String registerPost(@Valid MovieDTO movieDTO, BindingResult bindingResult, RedirectAttributes redirectAttributes){
        if (bindingResult.hasErrors()){

            log.info("에러 있음.");

            log.info("에러 있음.여기 백승민 다녀감. 예솔이도 다녀감");

            redirectAttributes.addFlashAttribute("errors", bindingResult.getAllErrors());
            return "redirect:/movie/register";
        }
        log.info(movieDTO);
        String movieName = movieService.register(movieDTO);
        redirectAttributes.addFlashAttribute("result", movieName);
        return "redirect:/movie/register";
    }

}
